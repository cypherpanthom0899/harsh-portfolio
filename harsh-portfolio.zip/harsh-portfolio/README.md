# harsh-portfolio

Source for the "Still Building" portfolio site. Spec: `design.md` (keep it in
this repo as the source of truth — this build follows it section by section).

## Status

This is a **placeholder-safe scaffold**, not the finished site. Per
`design.md` §16, real content (portrait, motivational images, personal
statement, projects) hasn't been supplied yet, so every section that needs
it is showing its intentional empty/pending state instead of inventing
anything. Nothing here violates the truth rules in §1.

## Stack

Astro (static-first, islands architecture) — see `ADR-001-static-site-framework.md`
for why. Content lives in one place: `src/data/site.ts`.

## Run it

```
npm install
npm run dev
```

## Add real content

Edit `src/data/site.ts` — every field that still needs a real value is
marked `TODO(harsh)`. Nothing else needs to change:

- `person.photo`, `person.statement`, `person.location`
- `learningItems` — add entries to replace "The Lab is active." empty state
- `projects` — add entries to replace "Work in progress." empty state
- `imageCredits` — required before the three motivational images ship

## What's built vs. what's still ahead

| Piece | Status |
| --- | --- |
| Nav (desktop + mobile menu) | Built — scroll backdrop, active-anchor, focus trap, Escape-to-close |
| Hero / skip intro | Built (static reveal, not the full 8–14s animated sequence yet) |
| Three-image manifesto | Structural placeholder only — swap in real images + the scroll-pin/zoom motion from §7 once assets exist |
| About / Lab / Work / Future / Footer | Built, content-driven, empty-safe |
| Accessibility (skip link, landmarks, focus-visible, reduced-motion) | Built |
| Performance (fonts, image optimization, JS budget) | Not yet tuned — do this once real assets are in |
| Sound | None (§13 default) |

## Deploy

This repo is meant to be linked to a Vercel project (Astro preset,
auto-detected). See `TESTING_STRATEGY.md` for the pre-launch checklist
before this goes live for real — especially the placeholder-leak and
canonical-copy checks.
